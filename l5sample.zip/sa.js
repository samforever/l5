$(document).ready(function(){
    alert('ahoj');
});
$(document).ready(function(){
    alert('ahoj');
});