<?php namespace Dorucuji\Events;

abstract class Event {

	//

}
