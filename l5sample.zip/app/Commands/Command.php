<?php namespace Dorucuji\Commands;

abstract class Command {

	//

}
