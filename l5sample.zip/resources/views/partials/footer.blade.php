<footer id="footer">
    <div class="content-wrapper">
        Zápatí
    </div>
</footer>