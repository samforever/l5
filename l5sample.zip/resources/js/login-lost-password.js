$( document ).ready(function() {

    $('.login-box .label-link').click(function(){

        $(this).hide();

        $('.login-box .hidden-form').fadeToggle();

    });

});